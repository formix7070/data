var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {

    $routeProvider.when('/', {
            templateUrl: 'templates/index.html',
            controller: 'MainController'
        }).when('/admin', {
            templateUrl: 'templates/admin.html',
            controller: 'AdminController'
        
        }).when('/employee', {
            templateUrl: 'templates/employee.html',
            controller: 'EmployeeController'
        
        }).otherwise({
            redirectTo: '/'

        })
});

app.controller('MainController', function($scope) {
 
    console.log("MainController is invoked with index.html file");
});

app.controller('AdminController', function($scope){

	console.log("AdminController is invoked with admin.html file");

})

app.controller('EmployeeController',function($scope){

	console.log("EmployeeController is invoked with employee.html file")
		$scope.employees = [
			{
			id:001,
			name:"Vijay"
			},
			{
			id:002,
			name:"John"
			},
			{
			id:003,
			name:"Mike"
			}];

			console.log($scope.employees);
});