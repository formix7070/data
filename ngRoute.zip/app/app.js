var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {

    $routeProvider.when('/', {
            templateUrl: 'templates/mainTemplate.html',
            controller: 'MainCtrl'
        })
        .when('/userdetails', {
            templateUrl: 'templates/userDetailsTemplate.html',
            controller: 'userListingCtrl'
        }).when('/userdetails/:userId', {
            templateUrl: 'templates/userOverviewTemplate.html',
            controller: 'userDetailsCtrl'
        }).otherwise({
            redirectTo: '/'
        })
});

app.controller('MainCtrl', function($scope) {
    console.log('MainCtrl invoked!');
});

app.controller('userListingCtrl', function($scope) {
    //  console.log('userDetailsCtrl invoked with userId: ' + $routeParams.userId);
    console.log('userListingCtrl invoked');

});

app.controller('userDetailsCtrl', function($scope, $routeParams) {
    //  console.log('userDetailsCtrl invoked with userId: ' + $routeParams.userId);
    console.log('userDetailsCtrl invoked');
    $scope.id = $routeParams.userId;
});