var app = angular.module('Myapp',['ngroute']);



app.config(function($routeProvider) {

    $routeProvider.when('/', {
            templateUrl: 'templates/index.html',
            controller: 'userListingCtrl'
        })
        .when('/employee', {
            templateUrl: 'templates/employee.html',
            controller: 'MainController'
        
        }).otherwise({
            redirectTo: '/'
        })
});


app.controller('userListingCtrl', function($scope) {
    //  console.log('userDetailsCtrl invoked with userId: ' + $routeParams.userId);
    console.log('userListingCtrl invoked');

});


app.controller('MainController', function($scope) {

$scope.employees = [
	{
	id:001,
	name:"Vijay"
	},
	{
	id:002,
	name:"John"
	},
	{
	id:003,
	name:"Mike"
	}];

	console.log($scope.employees);
    
});

